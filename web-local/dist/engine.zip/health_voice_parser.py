import re
PATTERNS = {
    'heart_rate': (r'heart rate (?:as|is) (.+) beats per minute', 'beats/min'),
    'blood_pressure': (r'blood pressure (?:as|is) (.+) over (.+?)(?: millimeters of mercury)?', 'mmHg'),
    'temperature': (r'temperature (?:as|is) (.+) degrees celsius', 'Cel'),
    'body_mass': (r'(?:body mass|weight) (?:as|is) (.+) kilograms', 'kg'),
    'blood_glucose': (r'blood glucose (?:as|is) (.+) milligrams per deciliter', 'mg/dL'),
    'oxygen_saturation': (r'oxygen saturation (?:as|is) (.+) percent', '%'),
    'sleep_duration': (r'sleep duration (?:as|is) (.+) hours', 'h'),
    'exercise_duration': (r'exercise duration (?:as|is) (.+) minutes', 'min'),
    'pain_score': (r'pain score (?:as|is) (.+) out of ten', '1'),
    'fatigue_score': (r'fatigue score (?:as|is) (.+) out of ten', '1'),
}

DIGITS = dict(zip('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split(), range(20)))

TENS = dict(zip('twenty thirty forty fifty sixty seventy eighty ninety'.split(), range(20, 100, 10)))

def number(text):
    if re.fullmatch(r'[0-9]{1,4}(?:\.[0-9]{1,3})?', text):
        return float(text)
    left, separator, right = text.partition(' point ')
    words = left.split()
    total = 0
    if len(words) >= 2 and words[1] == 'hundred' and 1 <= DIGITS.get(words[0], 0) <= 9:
        total = DIGITS[words[0]] * 100
        words = words[2:]
    if len(words) == 1 and words[0] in DIGITS | TENS:
        total += (DIGITS | TENS)[words[0]]
    elif len(words) == 2 and words[0] in TENS and 1 <= DIGITS.get(words[1], 0) <= 9:
        total += TENS[words[0]] + DIGITS[words[1]]
    elif words or not total:
        raise ValueError
    if separator:
        digits = right.split()
        if not 1 <= len(digits) <= 3 or any(DIGITS.get(d, 10) > 9 for d in digits):
            raise ValueError
        total += float('0.' + ''.join(str(DIGITS[d]) for d in digits))
    return total

def parse(text):
    statement = text.lower().strip().rstrip('.')
    if '?' in statement:
        return None
    statement = re.sub(r'^(?:asthral|astral),? ', '', statement)
    match = re.fullmatch(r'(record my|my) (.+)', statement)
    if not match:
        sleep = re.fullmatch(r'i slept (.+) hours last night', statement)
        if sleep:
            result = parse('my sleep duration is ' + sleep[1] + ' hours')
            return {**result, 'time_reference': 'LAST_NIGHT'} if result else {'kind': 'unresolved', 'structured': False}
        if statement.startswith(('i have a question', 'i have another question')):
            return None
        if re.match(r"^(?:i feel |i have |i've been feeling )", statement):
            return {'kind': 'symptom', 'structured': False}
        return None
    content = match[2]
    time_reference = None
    if content.endswith(' in the past twenty four hours'):
        content = content.removesuffix(' in the past twenty four hours')
        time_reference = 'PAST_24_HOURS'
    elif content.endswith(' right now'):
        content = content.removesuffix(' right now')
        time_reference = 'AT_RECORDING'
    for kind, (pattern, unit) in PATTERNS.items():
        measurement = re.fullmatch(pattern, content)
        if not measurement:
            continue
        try:
            values = [number(part) for part in measurement.groups()]
        except ValueError:
            break
        if kind in ('oxygen_saturation', 'pain_score', 'fatigue_score'):
            valid = all(0 <= v <= (100 if kind == 'oxygen_saturation' else 10) for v in values)
        else:
            valid = all(v > 0 for v in values)
        if kind in ('sleep_duration', 'exercise_duration'):
            valid &= values[0] <= (24 if unit == 'h' else 1440)
        if kind == 'blood_pressure':
            valid &= values[0] > values[1] and all(v.is_integer() for v in values)
        return {'kind': kind, 'structured': valid, 'values': values, 'unit': unit,
                'reported': measurement.groups(), 'time_reference': time_reference, 'explicit': match[1] == 'record my'}
    return {'kind': 'unresolved', 'structured': False} if match[1] == 'record my' else None
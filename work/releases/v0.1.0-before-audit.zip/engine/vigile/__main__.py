import argparse,json,secrets,hashlib
from pathlib import Path
from .registry import Registry
from .store import Store

def main():
    parser=argparse.ArgumentParser(description='VIGILE offline research engine')
    parser.add_argument('command',choices=['init','serve','audit','demo'])
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    if args.command=='init':
        data=root/'engine/data';data.mkdir(exist_ok=True)
        tokens=data/'tokens.json'
        if not tokens.exists():
            with tokens.open('x',encoding='utf-8') as f:
                json.dump({secrets.token_urlsafe(32):role for role in ['reader','operator','researcher','clinician']},f,indent=2)
        store=Store(data/'vigile.sqlite3');r=Registry(root);r.import_to(store);store.close()
        print('Initialized offline corpus and local credentials in engine/data/tokens.json. Protect this file; never give write tokens to the LLM.')
    elif args.command=='serve':
        import uvicorn
        from .api import create_app
        if not (root/'engine/data/tokens.json').exists():
            parser.error('Run python -m vigile init first, or use the documented uvicorn factory with VIGILE_TOKENS')
        uvicorn.run(create_app(),host='127.0.0.1',port=args.port,access_log=False)
    elif args.command=='audit':
        registry=Registry(root)
        print(json.dumps({'corpus':registry.fingerprint,'counts':{k:len(v) for k,v in registry.catalogs.items()},'issues':registry.issues},ensure_ascii=True,indent=2))
    else:
        from .demo import run
        print(json.dumps(run(root),indent=2))

if __name__=='__main__': main()

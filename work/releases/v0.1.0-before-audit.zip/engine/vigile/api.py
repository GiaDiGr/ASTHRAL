"""Local API. No write access to rules, evidence, authorization or audit."""
import os, json, hmac, sqlite3
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.responses import JSONResponse
from . import models as m
from .store import Store
from .registry import Registry
from .service import Engine
from .quality import Inconclusive

def create_app(root=None, db_path=None, tokens=None):
    root=Path(root or os.environ.get('VIGILE_CORPUS',Path(__file__).resolve().parents[2]))
    db_path=db_path or os.environ.get('VIGILE_DB',root/'engine/data/vigile.sqlite3')
    token_file=root/'engine/data/tokens.json'
    stored_tokens=json.loads(token_file.read_text(encoding='utf-8')) if token_file.exists() else {}
    tokens=dict(tokens if tokens is not None else json.loads(os.environ.get('VIGILE_TOKENS',json.dumps(stored_tokens))))
    if any(role not in ('reader','operator','researcher','clinician') for role in tokens.values()):
        raise ValueError('Unknown server role')
    if any(len(t)<24 for t in tokens): raise ValueError('API tokens must have at least 24 characters')
    store=Store(db_path); engine=Engine(Registry(root),store)
    @asynccontextmanager
    async def lifespan(app):
        yield
        store.close()
    app=FastAPI(title='VIGILE Health Intelligence Engine',version='0.1.0',docs_url=None,redoc_url=None,
                openapi_url=None,lifespan=lifespan)
    app.state.engine=engine

    @app.middleware('http')
    async def auth(request: Request, call_next):
        if request.url.path=='/health': return await call_next(request)
        header=request.headers.get('authorization','')
        token=header[7:] if header.startswith('Bearer ') else ''
        role=next((r for k,r in tokens.items() if hmac.compare_digest(token,k)),None)
        if not role:
            store.audit('AUTHENTICATION_DENIED','anonymous',{'method':request.method,'path':request.url.path})
            return JSONResponse({'detail':'UNAUTHORIZED'},status_code=401)
        request.state.actor=role
        if role=='reader' and request.method not in ('GET','HEAD'):
            store.audit('WRITE_DENIED',role,{'method':request.method,'path':request.url.path})
            return JSONResponse({'detail':'BLOCKED_NO_AUTHORIZATION'},status_code=403)
        return await call_next(request)

    def require(*roles):
        def check(request:Request):
            actor=request.state.actor
            if actor not in roles:
                store.audit('ROLE_DENIED',actor,{'path':request.url.path})
                raise HTTPException(403,'BLOCKED_NO_AUTHORIZATION')
            return actor
        return check
    write=Depends(require('operator','researcher','clinician'))
    research=Depends(require('researcher','clinician'))
    medical=Depends(require('clinician'))

    @app.exception_handler(KeyError)
    async def missing(request,exc): return JSONResponse({'detail':str(exc)},status_code=404)
    @app.exception_handler(ValueError)
    async def invalid(request,exc): return JSONResponse({'detail':str(exc)},status_code=422)
    @app.exception_handler(sqlite3.IntegrityError)
    async def conflict(request,exc): return JSONResponse({'detail':'IMMUTABLE_RECORD_CONFLICT'},status_code=409)

    @app.get('/health')
    def health(): return {'status':'ok','mode':'RESEARCH_ONLY','clinical_execution':'BLOCKED','version':'0.1.0'}
    @app.get('/openapi.json')
    def openapi(): return app.openapi()
    @app.get('/catalog/{kind}')
    def catalog(kind:str): return engine.registry.list(kind)
    @app.get('/conditions/{identifier}')
    def condition(identifier:str): return engine.registry.get('conditions',identifier)
    @app.get('/evidence/{identifier}')
    def evidence(identifier:str): return engine.registry.get('sources',identifier)
    @app.get('/rules')
    def rules(): return engine.registry.rule_status()
    @app.get('/evidence-issues')
    def issues(): return engine.registry.issues
    @app.get('/audit/verify')
    def verify(actor=Depends(require('researcher','clinician'))): return {'valid':store.verify()}
    @app.post('/missions',status_code=201)
    def mission(body:m.MissionContext,actor=research): return engine.register('mission',body,actor)
    @app.post('/profiles',status_code=201)
    def profile(body:m.AstronautProfile,actor=write): return engine.register('profile',body,actor)
    @app.post('/devices',status_code=201)
    def device(body:m.Device,actor=research): return engine.register('device',body,actor)
    @app.post('/measurements',status_code=201)
    def measurement(body:m.Measurement,actor=write): return engine.ingest(body,actor)
    @app.get('/measurements')
    def query_measurements(subject_id:str, mission_id:str, variable:str|None=None, limit:int=100):
        if not 1<=limit<=1000: raise HTTPException(422,'Limit must be 1..1000')
        rows=[r for r in store.all('measurement') if r['measurement']['subject_id']==subject_id and r['measurement']['mission_id']==mission_id and (variable is None or r['measurement']['variable']==variable)]
        return sorted(rows,key=lambda r:(r['measurement']['timestamp'],r['measurement']['id']))[-limit:]
    @app.get('/findings')
    def query_findings(subject_id:str,mission_id:str):
        return [r for r in store.all('finding') if r['subject_id']==subject_id and r['mission_id']==mission_id]
    @app.get('/episodes')
    def query_episodes(subject_id:str,mission_id:str):
        return [engine.episode(r['id']) for r in store.all('episode') if r['subject_id']==subject_id and r['mission_id']==mission_id]
    @app.get('/research-records/{kind}/{identifier}')
    def research_record(kind:str,identifier:str):
        if kind not in ('baseline','trend','followup','followup_review','multisystem','clinical_note'):
            raise HTTPException(404,'Record type not exposed')
        return store.get(kind,identifier)
    @app.get('/measurements/{identifier}')
    def read_measurement(identifier:str): return store.get('measurement',identifier)
    @app.post('/baselines',status_code=201)
    def baseline(body:m.BaselineRequest,actor=research): return engine.build_baseline(body,actor)
    @app.post('/trends',status_code=201)
    def trend(body:m.TrendRequest,actor=research): return engine.trend(body,actor)
    @app.post('/evaluations')
    def evaluate(body:m.EvaluationRequest,actor=research): return engine.evaluate(body,actor)
    @app.get('/findings/{identifier}')
    def finding(identifier:str): return store.get('finding',identifier)
    @app.get('/findings/{identifier}/explanation')
    def explanation(identifier:str): return engine.reproduce(identifier)
    @app.post('/episodes',status_code=201)
    def episode(body:m.EpisodeRequest,actor=research): return engine.open_episode(body,actor)
    @app.get('/episodes/{identifier}')
    def read_episode(identifier:str): return engine.episode(identifier)
    @app.get('/episodes/{identifier}/pathway')
    def pathway(identifier:str): return engine.pathway(identifier)
    @app.post('/episodes/{identifier}/transitions')
    def transition(identifier:str,body:m.TransitionRequest,actor=research): return engine.transition(identifier,body,actor)
    @app.post('/clinical-notes')
    def note(body:m.ClinicalNote,actor=medical): return engine.note(body,actor)
    @app.post('/action-requests')
    def action(body:m.ActionRequest,actor=write): return engine.action(body,actor)
    @app.post('/followups')
    def followup(body:m.FollowUpPlan,actor=medical): return engine.followup(body,actor)
    @app.post('/followups/reviews')
    def review(body:m.FollowUpReview,actor=medical): return engine.review_followup(body,actor)
    @app.post('/multisystem')
    def multisystem(body:m.MultisystemRequest,actor=research): return engine.multisystem(body,actor)
    return app

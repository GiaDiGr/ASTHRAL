from datetime import datetime, timezone
from uuid import uuid4
from pathlib import Path
import hashlib
from .models import Measurement, Device, MissionContext, AstronautProfile
from .store import digest
from .quality import assess, comparable, convert, Inconclusive
from .algorithms import baseline, trends, hour_average
from .rules import calculate, result

# Explicit adapters; no fuzzy variable/condition matching.
VARIABLES={
 'vo2max_relative':('physiology.vo2max','mL/min/kg'),
 'premission_aerobic_capacity':('physiology.vo2max','mL/min/kg'),
 'current_aerobic_capacity':('physiology.vo2max','mL/min/kg'),
 'baseline_strength':('physiology.strength','N'), 'current_strength':('physiology.strength','N'),
 'body_weight':('strength.body_weight','kg_equivalent'),
 'deadlift_strength_value':('strength.deadlift','kg_equivalent'),
 'bench_press_strength_value':('strength.bench_press','kg_equivalent'),
 'past_spaceflight_effective_dose':('radiation.career_spaceflight','mSv'),
 'projected_upcoming_mission_effective_dose':('radiation.projected_spaceflight','mSv'),
 'modeled_design_reference_spe_effective_dose':('radiation.design_spe','mSv'),
 'nuclear_technology_effective_dose':('radiation.nuclear','mSv'),
 'mission_year_equivalent':('mission.duration_equivalent','mission-year'),
 'crew_support_duration_days':('mission.support_duration','day'),
 'nasa_effective_gcr_dose_rate':('radiation.design_gcr_rate','mSv/day'),
 'diluent_fraction_percent':('environment.diluent','%'),
 'total_pressure':('environment.pressure','kPa'),
 'absolute_total_pressure_change':('environment.pressure_change','psi'),
 'maximum_absolute_pressure_change_rate':('environment.pressure_rate','psi/min'),
}
SERVER_CONTEXT={'data_quality_status','measurement_comparability','measurement_unit','test_id',
 'window_coverage_complete','aggregation_method_validated','compartment_id',
 'microgravity_eva_planned_or_required','extraterrestrial_surface_eva_planned_or_required',
 'exposure_context','environment','measurement_method'}

class Engine:
    def __init__(self, registry, store):
        self.registry,self.store=registry,store
        registry.import_to(store)
        self.implementation_hash=digest({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in Path(__file__).parent.glob("*.py")})

    def register(self, kind, model, actor):
        if kind=='profile': self.store.get('mission',model.mission_id)
        return self.store.put(kind,model.id,model.model_dump(mode='json'),actor)

    def ingest(self, m, actor):
        profile=self.store.get('profile',m.subject_id)
        mission=self.store.get('mission',m.mission_id)
        device=Device.model_validate(self.store.get('device',m.device_id))
        if profile['mission_id']!=m.mission_id or profile['synthetic']!=m.synthetic or mission['synthetic']!=m.synthetic:
            raise ValueError('Subject/mission/synthetic scope mismatch')
        state=assess(m,device,datetime.now(timezone.utc),historical=True)
        return self.store.put('measurement',m.id,{'measurement':m.model_dump(mode='json'),
                              'ingestion_quality':state},actor)

    def measurement(self, identifier):
        return Measurement.model_validate(self.store.get('measurement',identifier)['measurement'])

    def checked(self, identifier, as_of, historical=False):
        m=self.measurement(identifier)
        d=Device.model_validate(self.store.get('device',m.device_id))
        state=assess(m,d,as_of,historical)
        if state!='VALID': raise Inconclusive(state)
        if not historical:
            self.check_conflicts(m,d,as_of)
        return m

    def check_conflicts(self,m,d,as_of):
        for raw in self.store.all('measurement'):
            other=Measurement.model_validate(raw['measurement'])
            if other.device_id==m.device_id or (other.subject_id,other.mission_id,other.variable,other.compartment,other.site)!=(m.subject_id,m.mission_id,m.variable,m.compartment,m.site): continue
            od=Device.model_validate(self.store.get('device',other.device_id))
            if assess(other,od,as_of,True)!='VALID': continue
            overlap=(m.interval_end and other.interval_end and other.timestamp<m.interval_end and m.timestamp<other.interval_end)
            delta=abs((other.timestamp-m.timestamp).total_seconds())
            alignment=d.alignment_seconds if d.alignment_seconds is not None else 0
            if not overlap and delta>alignment: continue
            if d.conflict_tolerance is None: raise Inconclusive('MULTISENSOR_POLICY_REQUIRED')
            if abs(convert(other.value,other.unit,d.unit)-convert(m.value,m.unit,d.unit))>d.conflict_tolerance:
                raise Inconclusive('CONFLICTING_DATA')

    def resolve(self, identifier, as_of, historical=False):
        try:
            m=self.checked(identifier,as_of,historical)
            return m,{'measurement':m.model_dump(mode='json'),'device':self.store.get('device',m.device_id)}
        except KeyError:
            b=self.store.get('baseline',identifier)
            if not historical: raise Inconclusive('BASELINE_IN_CURRENT_SLOT')
            ms=[self.checked(mid,as_of,True) for mid in b['input_ids']]
            first=ms[0]
            m=first.model_copy(update={'id':identifier,'value':b['value'],'unit':b['unit'],
                                      'timestamp':max(x.timestamp for x in ms)})
            return m,{'baseline':b,'measurements':[x.model_dump(mode='json') for x in ms],
                      'devices':[self.store.get('device',x.device_id) for x in ms]}

    def evaluate(self, req, actor):
        mission=MissionContext.model_validate(self.store.get('mission',req.mission_id))
        profile=AstronautProfile.model_validate(self.store.get('profile',req.subject_id))
        rule=self.registry.rule(req.rule_id)
        snapshots=[]; conversions=[]; inputs={}; metric=None
        ctx={'mission_phase':mission.phase,'environment':mission.environment,'mode':mission.mode}
        try:
            if profile.mission_id!=mission.id: raise Inconclusive('SUBJECT_MISSION_MISMATCH')
            if req.mode!='SIMULATION':
                outcome=result('REQUIRES_VALIDATION','OPERATIONAL_ACTIVATION_BLOCKED')
            else:
                if not profile.synthetic or not mission.synthetic:
                    raise Inconclusive('SYNTHETIC_SCOPE_REQUIRED')
                allowed={f['name'] for f in rule['inputs'] if f['type'] not in ('number','map_anatomical_site_to_number','map_component_to_quantity')}-SERVER_CONTEXT
                allowed|={'radiation_context','nuclear_technology_emitting_ionizing_radiation_present','beyond_low_earth_orbit'}
                if set(req.context)-allowed: raise Inconclusive('CLIENT_CONTEXT_OVERRIDE_FORBIDDEN')
                inputs.update(req.context)
                ctx.update({k:req.context[k] for k in ('radiation_context','nuclear_technology_emitting_ionizing_radiation_present','beyond_low_earth_orbit') if k in req.context})
                for key in ('microgravity_eva_planned_or_required','extraterrestrial_surface_eva_planned_or_required','exposure_context'):
                    inputs[key]=getattr(mission,key)
                inputs['environment']=mission.environment
                resolved={}
                numeric_fields={f['name'] for f in rule['inputs'] if f['type'] in ('number','map_anatomical_site_to_number','map_component_to_quantity')}
                if set(req.bindings)-numeric_fields: raise Inconclusive('UNKNOWN_INPUT_BINDING')
                for key,binding in req.bindings.items():
                    historic=key.startswith('premission') or key.startswith('baseline')
                    members=binding if isinstance(binding,dict) else {'':binding}
                    if not members: raise Inconclusive('EMPTY_MEASUREMENT_MAP')
                    for site,identifier in members.items():
                        m,snapshot=self.resolve(identifier,req.as_of,historic)
                        snapshots.append(snapshot)
                        if m.subject_id!=req.subject_id or m.mission_id!=req.mission_id or not m.synthetic:
                            raise Inconclusive('MEASUREMENT_SCOPE_MISMATCH')
                        if historic and m.phase!='PRE_MISSION': raise Inconclusive('BASELINE_NOT_PREFLIGHT')
                        if not historic and m.phase!=mission.phase: raise Inconclusive('PHASE_MISMATCH')
                        if key in ('premission_bmd','current_bmd'):
                            if not site or m.site!=site: raise Inconclusive('ANATOMICAL_SITE_MISMATCH')
                            variable,unit='physiology.bmd','g/cm2'
                        elif key in ('calculated_requirements','provided_amounts'):
                            if not site: raise Inconclusive('MISSING_NUTRIENT_COMPONENT')
                            variable,unit='nutrition.'+site,m.unit
                        else:
                            if site or key not in VARIABLES: raise Inconclusive('UNSUPPORTED_INPUT_SHAPE')
                            variable,unit=VARIABLES[key]
                        if m.variable!=variable: raise Inconclusive('VARIABLE_MISMATCH')
                        if variable.startswith('environment.') and not m.compartment: raise Inconclusive('MISSING_COMPARTMENT')
                        value=convert(m.value,m.unit,unit)
                        conversions.append({'input_id':identifier,'from':m.unit,'to':unit,'original':m.value,'normalized':value})
                        if site: inputs.setdefault(key,{})[site]=value
                        else: inputs[key]=value
                        resolved[(key,site)]=m
                if req.rule_id in ('VIGILE-MUS-001','VIGILE-ENV-004','VIGILE-NUT-001') and resolved:
                    values=list(resolved.values())
                    if len({m.protocol for m in values})!=1:
                        raise Inconclusive('PROTOCOL_MISMATCH')
                    if req.rule_id in ('VIGILE-ENV-004','VIGILE-NUT-001'):
                        if len({(m.timestamp,m.interval_end) for m in values})!=1 or any(m.interval_end is None for m in values):
                            raise Inconclusive('ACCOUNTING_PERIOD_MISMATCH')
                pairs=[('premission_aerobic_capacity' ,'current_aerobic_capacity'),('baseline_strength','current_strength'),
                       ('premission_bmd','current_bmd'),('calculated_requirements','provided_amounts')]
                for b,c in pairs:
                    for (key,site),m in resolved.items():
                        if key!=b or (c,site) not in resolved: continue
                        current=resolved[(c,site)]
                        comparable([m,current],include_phase=False)
                        if b!='calculated_requirements' and current.timestamp<=m.timestamp:
                            raise Inconclusive('BASELINE_NOT_PRIOR')
                        if b=='calculated_requirements':
                            if m.timestamp!=current.timestamp or m.interval_end!=current.interval_end or not m.interval_end:
                                raise Inconclusive('NUTRITION_PERIOD_MISMATCH')
                            inputs[c][site]=convert(current.value,current.unit,m.unit)
                # Check the actual registered method, never a caller's method label.
                if ('vo2max_relative','') in resolved:
                    inputs['measurement_method']=resolved[('vo2max_relative','')].method
                if ('current_aerobic_capacity','') in resolved:
                    inputs['measurement_unit']=resolved[('current_aerobic_capacity','')].unit
                if ('current_strength','') in resolved:
                    inputs['test_id']=resolved[('current_strength','')].protocol
                inputs['measurement_comparability']='COMPARABLE'
                inputs['data_quality_status']='ACCEPTABLE'
                if req.rule_id=='VIGILE-ENV-002':
                    if 'one_hour_average_ppco2' in req.bindings: raise Inconclusive('DIRECT_CO2_AVERAGE_FORBIDDEN')
                    ms=[self.checked(mid,req.as_of,True) for mid in req.co2_measurement_ids]
                    for m in ms:
                        if m.subject_id!=req.subject_id or m.mission_id!=req.mission_id or not m.synthetic or m.phase!=mission.phase:
                            raise Inconclusive('MEASUREMENT_SCOPE_MISMATCH')
                        self.check_conflicts(m,Device.model_validate(self.store.get('device',m.device_id)),req.as_of)
                        snapshots.append({'measurement':m.model_dump(mode='json'),'device':self.store.get('device',m.device_id)})
                    metric=hour_average(ms,req.as_of)
                    inputs.update(one_hour_average_ppco2=metric['value'],window_coverage_complete=True,
                                  aggregation_method_validated=True,compartment_id=ms[0].compartment)
                elif req.co2_measurement_ids: raise Inconclusive('UNEXPECTED_CO2_INPUTS')
                outcome=calculate(rule,inputs,ctx)
        except (Inconclusive,KeyError) as exc:
            outcome=result('CONFLICTING_DATA' if str(exc)=='CONFLICTING_DATA' else 'INCONCLUSIVE',str(exc))
        bundle={'request':req.model_dump(mode='json'),'rule':rule,'rule_hash':digest(rule),
                'corpus_hash':self.registry.fingerprint,'mission':mission.model_dump(mode='json'),
                'profile':profile.model_dump(mode='json'),'snapshots':snapshots,'conversions':conversions,
                'normalized_inputs':inputs,'calculation_context':ctx,'metric':metric,
                'engine_version':'0.1.0','implementation_hash':self.implementation_hash,'algorithm_version':'1.0.0','outcome':outcome}
        identifier=digest(bundle)
        finding={'id':identifier,'kind':'NORMATIVE_COMPLIANCE_SIMULATION','rule_id':req.rule_id,
                 'subject_id':req.subject_id,'mission_id':req.mission_id,'timestamp':req.as_of.isoformat(),
                 'condition_ids':self.registry.conditions_for(req.rule_id),'bundle':bundle,**outcome}
        try:
            existing=self.store.get('finding',identifier)
            self.store.audit('REPLAY_REQUEST',actor,{'finding_id':identifier})
            return existing
        except KeyError:
            return self.store.put('finding',identifier,finding,actor)

    def reproduce(self, identifier):
        finding=self.store.get('finding',identifier)
        if 'bundle' not in finding:
            return {'finding_id':identifier,'verified':True,'replay_scope':'HUMAN_RECORD_ONLY','finding':finding}
        b=finding['bundle']
        if b['implementation_hash']!=self.implementation_hash:
            raise ValueError('ENGINE_VERSION_UNAVAILABLE_FOR_REPLAY')
        if digest(b)!=identifier or digest(b['rule'])!=b['rule_hash']:
            raise ValueError('REPRODUCTION_HASH_MISMATCH')
        # Precondition blocks are reproduced from the immutable decision bundle.
        if finding['result'] in ('REQUIREMENT_MET','REQUIREMENT_NOT_MET','NOT_APPLICABLE','REQUIRES_MISSION_AUTHORIZATION'):
            replay=calculate(b['rule'],b['normalized_inputs'],b['calculation_context'])
            if replay!=b['outcome']: raise ValueError('REPRODUCTION_RESULT_MISMATCH')
            scope='COMPARATOR_REEXECUTED'
        else:
            replay=b['outcome']; scope='PRECONDITION_BUNDLE_INTEGRITY_VERIFIED'
        return {'finding_id':identifier,'verified':True,'replay_scope':scope,'outcome':replay,'bundle':b}

    def build_baseline(self, req, actor):
        ms=[self.checked(mid,req.as_of,True) for mid in req.measurement_ids]
        b=baseline(ms,req.minimum_observations)
        return self.store.put('baseline',req.id,{**b,'id':req.id,'request':req.model_dump(mode='json')},actor)

    def trend(self, req, actor):
        ms=[self.checked(mid,req.as_of,True) for mid in req.measurement_ids]
        out=trends(ms,req.ewma_lambda,req.cusum_target,req.cusum_allowance)
        payload={'request':req.model_dump(mode='json'),**out}
        return self.store.put('trend',uuid4().hex,payload,actor)

    def open_episode(self, req, actor):
        self.registry.get('conditions',req.condition_id)
        p=self.store.get('profile',req.subject_id)
        if p['mission_id']!=req.mission_id: raise ValueError('Episode mission mismatch')
        for fid in req.finding_ids:
            f=self.store.get('finding',fid)
            if (f['subject_id'],f['mission_id'])!=(req.subject_id,req.mission_id) or req.condition_id not in f['condition_ids']:
                raise ValueError('Finding episode scope mismatch')
        payload={**req.model_dump(mode='json'),'state':'FINDING' if req.finding_ids else 'MONITORING',
                 'authorization_state':'NONE'}
        return self.store.put('episode',req.id,payload,actor)

    def episode(self, identifier):
        e=self.store.get('episode',identifier)
        transitions=[t for t in self.store.all('transition') if t['episode_id']==identifier]
        if transitions: e['state']=transitions[-1]['target']
        e['transitions']=transitions
        return e

    def transition(self, identifier, req, actor):
        with self.store.lock:
            e=self.episode(identifier)
            # No diagnostic or therapeutic protocol is supplied/authorized in this corpus.
            if req.target in ('TRIAGE','AUTHORIZED_ACTION'):
                self.store.audit('BLOCKED_TRANSITION',actor,{'episode_id':identifier,'target':req.target})
                return {'result':'BLOCKED_NO_AUTHORIZATION','state':e['state']}
            allowed={'MONITORING':['FINDING','ASSESSMENT'], 'FINDING':['ASSESSMENT'],
                     'ASSESSMENT':['RECOVERY','FOLLOW_UP'], 'RECOVERY':['FOLLOW_UP'], 'FOLLOW_UP':['CLOSED']}
            if req.target not in allowed.get(e['state'],[]): raise ValueError('INVALID_EPISODE_TRANSITION')
            if req.target in ('RECOVERY','FOLLOW_UP','CLOSED') and actor!='clinician':
                self.store.audit('BLOCKED_TRANSITION',actor,{'episode_id':identifier,'target':req.target})
                return {'result':'BLOCKED_NO_AUTHORIZATION','state':e['state']}
            t={'episode_id':identifier,'previous':e['state'],**req.model_dump(mode='json'),
               'semantic':'HUMAN_DOCUMENTED_WORKFLOW_NOT_CLINICAL_OUTCOME'}
            self.store.put('transition',uuid4().hex,t,actor)
            return self.episode(identifier)

    def note(self, req, actor):
        episode=self.episode(req.episode_id)
        if req.kind=='DIAGNOSIS':
            self.store.audit('BLOCKED_DIAGNOSIS',actor,req.model_dump(mode='json'))
            return {'result':'BLOCKED_NO_AUTHORIZATION'}
        for eid in req.evidence_ids: self.registry.get('extractions',eid)
        note=self.store.put('clinical_note',req.id,{**req.model_dump(mode='json'),
                             'status':'HUMAN_MEDICAL_REVIEW_REQUIRED','diagnosis':None},actor)
        if req.kind=='OBSERVATION':
            finding={'id':digest(note),'kind':'HUMAN_REPORTED_FINDING','result':'FINDING','diagnosis':None,
                'status':'HUMAN_MEDICAL_REVIEW_REQUIRED','subject_id':episode['subject_id'],
                'mission_id':episode['mission_id'],'timestamp':req.observed_at.isoformat(),
                'condition_ids':[episode['condition_id']],'note_id':req.id,'evidence_ids':req.evidence_ids}
            self.store.put('finding',finding['id'],finding,actor)
            note['finding_id']=finding['id']
        return note

    def action(self, req, actor):
        e=self.episode(req.episode_id)
        mission=self.store.get('mission',e['mission_id'])
        reason='BLOCKED_CONTEXT_NOT_APPLICABLE' if req.action=='postflight_standing_test' and mission['gravity']=='MICROGRAVITY' else 'BLOCKED_NO_AUTHORIZATION'
        self.store.audit('BLOCKED_ACTION',actor,{**req.model_dump(mode='json'),'result':reason})
        return {'result':reason,'protocol_status':'AUTHORIZED_PROTOCOL_REQUIRED','executed':False}

    def pathway(self, identifier):
        e=self.episode(identifier)
        c=self.registry.get('conditions',e['condition_id'])
        return {'episode':e,'condition':c,'assessment':'HUMAN_MEDICAL_REVIEW_REQUIRED',
                'intervention':'AUTHORIZED_PROTOCOL_REQUIRED','diagnosis':None,'therapeutic_steps':[]}

    def followup(self, req, actor):
        self.episode(req.episode_id)
        return self.store.put('followup',req.id,{**req.model_dump(mode='json'),'status':'HUMAN_PLAN_RECORDED',
                              'automatic_recovery_determination':False},actor)

    def review_followup(self, req, actor):
        plan=self.store.get('followup',req.plan_id); e=self.episode(plan['episode_id'])
        for mid in req.measurement_ids:
            m=self.measurement(mid)
            if (m.subject_id,m.mission_id)!=(e['subject_id'],e['mission_id']): raise ValueError('Follow-up scope mismatch')
        return self.store.put('followup_review',uuid4().hex,{**req.model_dump(mode='json'),
                              'recovery_status':'HUMAN_ASSESSMENT_REQUIRED'},actor)

    def multisystem(self, req, actor):
        interaction=self.registry.get('interactions',req.interaction_id)
        fs=[self.store.get('finding',i) for i in req.finding_ids]
        if len(set(req.finding_ids))!=len(fs): raise ValueError('Duplicate finding')
        if len({(f['subject_id'],f['mission_id']) for f in fs})!=1: raise ValueError('Multisystem scope mismatch')
        if any(f['result'] not in ('REQUIREMENT_NOT_MET','FINDING','STATISTICAL_DEVIATION') for f in fs):
            raise ValueError('Only actual findings may co-occur')
        times=[datetime.fromisoformat(f['timestamp']) for f in fs]
        if (max(times)-min(times)).total_seconds()>req.max_separation_seconds: raise ValueError('Temporal mismatch')
        groups={'MSI01':[{'C012','C013'},{'C014','C015'}], 'MSI02':[{'C012','C013','C016'},{'C018','C019'}],
          'MSI03':[{'C004','C008'},{'C005'}], 'MSI04':[{'C003'},{'C021'}],
          'MSI05':[{'C001'},{'C002','C003','C004'}], 'MSI06':[{'C027'},{'C008','C015','C041'}],
          'MSI07':[{'C023'},{'C001','C002','C003','C018'}], 'MSI08':[{'C009'},{'C008'}],
          'MSI09':[{'C037'},{'C030','C026','C027','C014','C038'}], 'MSI10':[{'C040'},{'C023','C004','C018'}],
          'MSI11':[{'C011'},{'C043','C004'}], 'MSI12':[{'C028'},{'C004','C015','C016','C041'}]}
        present=set(cid for f in fs for cid in f['condition_ids'])
        if not all(present & g for g in groups[req.interaction_id]): raise ValueError('Interaction condition mismatch')
        payload={'kind':'MULTISYSTEM_FINDING','status':'RESEARCH_ONLY','diagnosis':None,
                 'causality':'NOT_INFERRED','interaction':interaction,'request':req.model_dump(mode='json')}
        return self.store.put('multisystem',uuid4().hex,payload,actor)

# Verificación de software

Fecha de entrega: 2026-10-14 (America/Lima).

- Suite final ejecutada: 124 passed, 0 failed; reporte JUnit en pytest-results.xml.
- 43 casos embebidos de los 15 originales ejecutados; todos TC001–TC020 adaptados a fixtures reproducibles.
- Casos negativos: unidades incompatibles, tasa/dosis, datos ausentes/UNKNOWN/INVALID/stale/futuros, calibración, método/sitio/protocolo, fase/EVA, permisos, input coercion, contexto falsificado y sujetos cruzados.
- Auditoría, reproducción determinista, idempotencia, triggers append-only, reapertura SQLite y episodios/seguimiento probados.
- Simulación por API: measurement → evaluación → hallazgo → episodio → bloqueo de tratamiento → replay → persistencia tras reapertura, correcta.
- Servidor Uvicorn real en loopback: health y catálogo autenticado de 44 condiciones correctos, proceso terminado al finalizar prueba.
- Dependencias fijadas y wheelhouse local. Verificación de instalación --no-index en entorno nuevo registrada al entregar.
- Un warning: Starlette avisa de deprecación futura de httpx en TestClient; tests actuales pasan. No es fallo biomédico.

Las pruebas verifican lógica de software y contratos sintéticos. No prueban sensibilidad/especificidad clínica ni cumplimiento operacional NASA. Las banderas de métodos aprobados en fixtures son supuestos de prueba, no autorizaciones reales. TC003 comprueba el comparador puro; otros casos usan servicio/API según el tipo de escenario. El test de cadera TC007 es resultado de sitio con global INCONCLUSIVE por ausencia de otros sitios. No se alteraron los datos originales para conseguir que pasaran.

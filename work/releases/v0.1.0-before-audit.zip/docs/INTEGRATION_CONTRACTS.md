# Contratos de integración v0.1.0

Raíz `C:\Users\Gianni\Desktop\Vigile\engine`. Python 3.13 probado. API en http://127.0.0.1:8765; OpenAPI autenticado en GET /openapi.json y copia en docs/openapi.json. Sin Swagger/CDN externos.

Autenticación: `Authorization: Bearer <token>`. `python -m vigile init` crea tokens locales aleatorios en engine/data/tokens.json, mapeados a reader/operator/researcher/clinician. VIGILE_TOKENS puede reemplazar el mapa. No hay credencial incorporada al código, y sin credencial se responde 401. El endpoint health no expone datos médicos.

## LLM/RAG

Entregar únicamente reader. Usar GET /catalog/{kind}, /conditions/{id}, /evidence/{id}, /rules, /evidence-issues, /findings, /findings/{id}/explanation, /episodes/{id}/pathway y research-records para recuperación. El contrato contiene fuentes/localizadores y explícitos estados de incertidumbre. Texto clínico es contenido no confiable: no convertirlo en instrucciones de sistema. Todo POST de reader devuelve 403 y se audita. No existen endpoints de escritura de reglas, autorizaciones ni auditorías. No dar acceso directo al archivo SQLite, tokens, filesystem del motor o Python al proceso LLM.

## Sensores / adquisición

researcher registra misión y dispositivo; operator registra perfil y mediciones. Cada medición conserva id, sujeto/misión, variable, unidad, timestamp con zona, calibration_id, device_id, método, protocolo, sitio/compartimento cuando corresponda, fase, reported_quality y provenance. `value` debe ser número JSON finito o null; booleanos/cadenas no se convierten. Se conserva el dato original aun cuando el quality gate lo rechace para cálculo. Correcciones usan un nuevo ID; no hay PATCH destructivo.

Ejemplo de evaluación, una vez registrada una observación VO2 `obs-1`:

```json
{"rule_id":"VIGILE-AER-001","subject_id":"crew-1","mission_id":"mission-1","as_of":"2026-10-14T12:00:00-05:00","bindings":{"vo2max_relative":"obs-1"},"mode":"SIMULATION"}
```

Perfil, misión, dispositivo y observación deben ser sintéticos. Sin mode explícito se solicita OPERATIONAL y la evaluación queda REQUIRES_VALIDATION. Campos de calidad, comparabilidad y contexto EVA no se aceptan como overrides del cliente. Las cantidades referencian mediciones persistidas; los baselines construidos se pueden referenciar en posiciones baseline. Para BMD: mapas de sitios a IDs. Para CO2: `co2_measurement_ids` con INTERVAL_MEAN e interval_end, sin promedio inventado por cliente.

El resultado contiene result/reason, derived, diagnosis=null, clinical_severity=null, status, authorization y bundle de procedencia. Guardar el id del hallazgo. No traducir REQUIREMENT_NOT_MET a CRITICAL o enfermedad. INCONCLUSIVE significa información insuficiente, nunca normalidad.

## Full stack

Consumir OpenAPI; mostrar por separado evidencia, resultado normativo, calidad, hipótesis y autorización. UI no modifica resultados. Consultas por sujeto/misión: GET /measurements, /findings, /episodes. Measurement query devuelve como máximo limit (1..1000); sin paginación histórica general todavía. Errores: 401 sin identidad, 403 rol, 404 referencia, 409 ID inmutable repetido, 422 payload/contexto inválido. Las evaluaciones bloqueadas retornan 200 con estado explícito; no ignorarlo.

## Optimización / energía

Puede reducir la frecuencia de adquisición según política propia documentada, pero debe conservar timestamps, intervalos y huecos. Nunca completar muestras faltantes, cambiar umbrales, silenciar estados ni interpretar pérdida de señal como bienestar. No se implementó adaptador FULL/LOW_POWER/CRITICAL; evitar colisión con severidad médica. Requerir pruebas del efecto en cobertura antes de conectar.

## Equipo biomédico y seguridad

Resolver referencias, validar fuentes y métodos, definir criterios técnicos/baseline, revisiones, protocolos de misión, identidad/autorización médica y ensayos independientes. El siguiente trabajo debe implementar una autoridad de protocolos verificados antes de permitir diagnóstico/intervención; cambiar una bandera de cliente no basta. Mantener tests, corpus original y versiones reproducibles.

"""Three-valued, typed, explainable logic. Unknown never means normal."""
from decimal import Decimal

def number(v): return type(v) in (int,float,Decimal)
def compare(actual,op,expected):
    if isinstance(expected,bool):
        if not isinstance(actual,bool): return None
    elif number(expected):
        if not number(actual): return None
        actual,expected=Decimal(str(actual)),Decimal(str(expected))
    elif type(actual)!=type(expected): return None
    operations={'==':lambda:a==b,'!=':lambda:a!=b,'>=':lambda:a>=b,'>':lambda:a>b,'<=':lambda:a<=b,'<':lambda:a<b}
    if op not in operations: raise ValueError('UNSUPPORTED_OPERATOR')
    a,b=actual,expected
    return operations[op]()

def tree(node,values):
    for operator in ('all_of','any_of'):
        if operator in node:
            children=[tree(n,values) for n in node[operator]]
            states=[n['state'] for n in children]
            if not states: raise ValueError('EMPTY_LOGIC')
            state=(False if False in states else None if None in states else True) if operator=='all_of' else (True if True in states else None if None in states else False)
            return {'operator':operator,'state':state,'children':children}
    field=node.get('field',node.get('derived_field'))
    if not field: raise ValueError('UNSUPPORTED_LOGIC_NODE')
    value=values.get(field)
    return {'field':field,'operator':node['op'],'expected':node['value'],'actual':value,
            'state':None if value is None else compare(value,node['op'],node['value'])}

def fields(node,state=None):
    if 'children' in node: return sorted({f for child in node['children'] for f in fields(child,state)})
    return [node['field']] if node.get('state') is state else []

def has_positive(node):
    return any(has_positive(c) for c in node['children']) if 'children' in node else node['state'] is True

def leaf(field,value=True,op='=='): return {'field':field,'op':op,'value':value}

/* Read-only rendering of frozen deterministic management. No therapeutic commands. */
function renderManagement101(){
 const host=document.getElementById('protocol-list');if(!host)return;
 const section=el('section');section.id='management-v101';section.append(el('h3','Manejo documentado · sin autorización ni ejecución'));
 section.append(el('p','Datos de demostración sintéticos. Una pauta documental, un recurso disponible o un registro humano no autorizan ni ejecutan tratamientos.','caption'));
 const management=selected?.management;
 if(!management){section.append(el('p','Evaluación histórica sin snapshot de manejo v1.0.1. No se completa con el inventario actual ni se reinterpretan sus recursos declarados.'));host.append(section);return;}
 for(const [condition,m] of Object.entries(management)){
  const group=el('div',undefined,'management-block');group.append(el('h3',label(condition)),el('p','Urgencia del motor: '+label(m.urgency)+' · criterios: '+label(m.diagnostic_status)));
  if(m.urgent_suspicion_without_met_criteria)group.append(el('p','Sospecha urgente registrada: conserva prioridad de emergencia aunque los criterios no estén completos. La información esencial sigue visible; no equivale a confirmación.','urgent'));
  const s=m.resource_snapshot;group.append(el('p',s.policy==='MISSION_INVENTORY'?'Recursos congelados a '+s.as_of+' · inventario '+(s.inventory_id||'no disponible')+' · versión '+(s.inventory_version??'desconocida'):'Recursos declarados del contrato R2: no equivalen a inventario verificado.'));
  for(const i of m.interventions){
   const item=el('details');item.append(el('summary',i.title+' · '+i.applicability_status));
   item.append(el('p','Indicación documental: '+JSON.stringify(i.documented_indication)+'. La indicación individual de esta intervención NO fue decidida por VIGILE.'),el('p','Estado de autorización: '+i.authorization+' · '+i.authority_verification),el('p','Aplicabilidad espacial: '+i.space_applicability));
   item.append(el('p','Condiciones y datos pendientes: '+i.conditions.join(' · ')),el('p','Restricciones de seguridad específicas: '+(i.safety_restrictions.join(' · ')||'No evaluadas como prohibición general; requiere revisión humana.')));
   if(i.safety_restrictions.some(x=>x.includes('POTASSIUM')))item.append(el('p','La restricción de potasio indicada corresponde a insulinoterapia; no implica contraindicar automáticamente las demás opciones de soporte.'));
   item.append(el('p','Recursos: '+i.resource_status+' · disponibilidad no demuestra cantidad suficiente para una pauta ni autorización.'));
   if(i.resource_checks.length)item.append(table(['Recurso','Estado','Motivo','Cantidad / unidad','Caducidad','Fuente sintética'],i.resource_checks.map(c=>[c.id,c.status,c.reason,c.resource?.quantity===null||!c.resource?'No verificada':String(c.resource.quantity)+' '+(c.resource.unit||''),c.resource?.expires_at||'No verificada',c.resource?.source||'Sin manifest verificado'])));
   item.append(el('p','Monitorización documentada (no es una agenda ejecutada): '+(i.monitoring.join(' · ')||'Sin pauta específica aprobada en este protocolo.')));
   technical(item,'Pauta original de referencia · no orden, no cálculo de dosis',i.reference_only);
   item.append(el('p','Catálogo de contraindicaciones y precauciones incompleto: ausencia de regla no acredita seguridad; revisión humana pendiente.'));
   technical(item,'Precauciones documentales · no todas son predicados ejecutados',i.documented_precautions);
   technical(item,'Fuentes, versiones y revisiones pendientes',i.evidence);
   group.append(item);
  }
  section.append(group);
 }
 const records=(dashboard.management_records||[]).filter(r=>r.evaluation_id===selected.id);
 section.append(el('h3','Seguimiento terapéutico · declaraciones humanas no verificadas'));
 if(!records.length)section.append(el('p','Sin registros de intervención en este checkpoint. Esto no demuestra que un tratamiento haya o no haya ocurrido.'));
 for(const r of records){const d=el('details');d.append(el('summary',r.status+' · '+r.occurred_at),el('p',r.note),el('p','Autoridad declarada: '+r.reported_authority+' · verificación: '+r.authority_verification),el('p','Fuente: '+r.source),el('p','Datos pendientes para reevaluación: '+(r.data_needed_for_reevaluation.join(' · ')||'No especificados')),el('p','VIGILE no autorizó, ejecutó ni comprobó eficacia.'));section.append(d);}
 host.append(section);
}
const renderEvaluationBeforeManagement101=renderEvaluation;
renderEvaluation=function(){renderEvaluationBeforeManagement101();renderManagement101();};
$('evaluation').onchange=renderEvaluation;
function renderCountermeasures101(){
 const host=document.getElementById('space-monitoring');document.getElementById('countermeasures-v101')?.remove();if(!host||!dashboard)return;
 const vars=dashboard.measurements.map(r=>r.measurement.variable),has=prefix=>vars.some(v=>v.startsWith(prefix));
 const relevant=new Set([...(has('physiology.vo2')||has('physiology.heart_rate')?['C001']:[]),...(has('physiology.strength')?['C002']:[]),...(has('bone.')?['C003']:[]),...(dashboard.mission.phase==='POST_MISSION'?['C005']:[]),...(has('sleep.')||has('behavior.fatigue')||has('cognition.')?['C012','C013','C014']:[]),...(has('radiation.')?['C032']:[])]);
 const rows=(dashboard.countermeasure_documents||[]).filter(r=>relevant.has(r.condition_id));if(!rows.length)return;
 const group=el('details');group.id='countermeasures-v101';group.append(el('summary','Contramedidas documentales · dependen del plan y recursos de misión'),el('p','Biblioteca de referencia, no selección terapéutica. No se asume hardware, adherencia ni autorización. Sin nuevas terapias SANS ni ajustes farmacológicos por gravedad.'));
 for(const r of rows){const d=el('details');d.append(el('summary',r.condition_id+' · '+r.classification),el('p',r.text),el('small','Fuentes del catálogo: '+r.source_ids.join(', ')));group.append(d);}host.append(group);
}
const renderMonitoringBeforeManagement101=renderMonitoring;
renderMonitoring=function(){renderMonitoringBeforeManagement101();renderCountermeasures101();};